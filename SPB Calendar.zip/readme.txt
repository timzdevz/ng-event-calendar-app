1. npm install && bower install
2. grunt serve
3. enjoy!