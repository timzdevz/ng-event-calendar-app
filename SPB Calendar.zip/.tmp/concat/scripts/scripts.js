'use strict';

angular.module('spbtvcalendarApp', [
  'ngStorage'
]).run(["$rootScope", function ($rootScope) {
  // integrate lodash into views
  $rootScope._ = window._;
}]);

var SpbTVCalendar = SpbTVCalendar || {};

// helper functions go here
SpbTVCalendar.helpers = {
  HorizontallyBound: function ($parentElem, $childElem) {
    var parentRect = $parentElem[0].getBoundingClientRect();
    var childRect = $childElem[0].getBoundingClientRect();

    return parentRect.left <= childRect.left && parentRect.right >= childRect.right;
  }
};

'use strict';

angular.module('spbtvcalendarApp')
  .controller('CalendarCtrl', ["$scope", "EventCalendar", "EventService", function ($scope, EventCalendar, EventService) {
    $scope.cal = new EventCalendar();

    loadCalData();

    $scope.nextMonth = function() {
      $scope.cal.nextMonth();
      loadCalData();
    };

    $scope.prevMonth = function() {
      $scope.cal.prevMonth();
      loadCalData();
    };

    $scope.addEvent = function(event, date) {
      return EventService.addEvent(event, date);
    };

    $scope.removeEvent = function(event, date) {
      EventService.removeEvent(event.id, date);
    };

    function loadCalData() {
      $scope.displayDates = getDisplayDates();
    }

    function getDisplayDates() {
      return _.chunk(
        $scope.cal.getDatesForMonthDisplay(),
        $scope.cal.daysOfTheWeek.length);
    }

  }]);

'use strict';

angular.module('spbtvcalendarApp').factory('EventCalendar', ["EventService", function (EventService) {

  var monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];

  var daysOfTheWeek = ['Sun', 'Mon', 'Tues', 'Wed', 'Thu', 'Fri', 'Sat'];
  var daysInTheWeek = 7;
  var rowsInTheCalendar = 6;
  var totalDaysInCalendarDisplay = daysInTheWeek * rowsInTheCalendar;

  function Calendar() {
    this.currentDate = new Date();
    this.currentDate.setHours(0, 0, 0, 0);
    this.currentMonth = this.currentDate.getMonth();
    this.currentYear = this.currentDate.getFullYear();

    this.daysOfTheWeek = daysOfTheWeek;
  }

  Calendar.prototype.getDatesForMonthDisplay = function () {
    var firstDayOfMonthDate = new Date(this.currentYear, this.currentMonth, 1);
    var lastDayOfMonthDate = new Date(this.currentYear, this.currentMonth + 1, 0);

    var daysToPrepend = firstDayOfMonthDate.getDay();
    var daysToAppend = daysInTheWeek - (lastDayOfMonthDate.getDay() + 1);

    var currentMonthDates = [];

    for (var i = 1; i <= lastDayOfMonthDate.getDate(); i++) {
      var date = new Date(this.currentYear, this.currentMonth, i);
      date.currentMonthDate = true;
      if (date.getTime() === this.currentDate.getTime()) {
        date.currentDate = true;
      }

      currentMonthDates.push(date);
    }

    //  let's append 6th row in calendar in case there is none
    var totalDaysToAppend = daysToAppend +
      (totalDaysInCalendarDisplay - (daysToPrepend + daysToAppend + currentMonthDates.length));

    var datesToDisplay = this.extendByDays(daysToPrepend, totalDaysToAppend, currentMonthDates);

    _.forEach(datesToDisplay, function (date) {
      date.events = EventService.getEvents(date);

    });

    return datesToDisplay;
  };

  Calendar.prototype.nextMonth = function () {
    var date = this.increaseMonth(this.currentMonth, this.currentYear);
    this.currentYear = date.getFullYear();
    this.currentMonth = date.getMonth();
  };

  Calendar.prototype.prevMonth = function () {
    var date = this.decreaseMonth(this.currentMonth, this.currentYear);
    this.currentYear = date.getFullYear();
    this.currentMonth = date.getMonth();
  };

  Calendar.prototype.getMonthName = function () {
    return monthNames[this.currentMonth];
  };

  Calendar.prototype.extendByDays = function (daysToPrepend, daysToAppend, currentMonthDates) {
    var datesToPrepend = [];
    var datesToAppend = [];
    var monthDate = currentMonthDates[0];

    var prevMonthDate = this.decreaseMonth(monthDate.getMonth(), monthDate.getFullYear());
    var nextMonthDate = this.increaseMonth(monthDate.getMonth(), monthDate.getFullYear());

    var daysInPrevMonth = this.getDaysInMonth(prevMonthDate.getMonth(), prevMonthDate.getFullYear());

    if (daysToPrepend > 0) {
      for (var i = 0; i < daysToPrepend; i++) {
        datesToPrepend.push(
          new Date(prevMonthDate.getFullYear(), prevMonthDate.getMonth(), daysInPrevMonth - i));
      }
      datesToPrepend.reverse();
    }

    if (daysToAppend > 0) {
      for (var k = 1; k <= daysToAppend; k++) {
        datesToAppend.push(new Date(nextMonthDate.getFullYear(), nextMonthDate.getMonth(), k));
      }
    }

    var datesToDisplay = datesToPrepend.concat(currentMonthDates);
    datesToDisplay = datesToDisplay.concat(datesToAppend);

    return datesToDisplay;
  };

  Calendar.prototype.increaseMonth = function (month, year) {
    if (++month > 11) {
      month = 0;
      year++;
    }

    return new Date(year, month);
  };

  Calendar.prototype.decreaseMonth = function (month, year) {
    if (--month < 0) {
      month = 11;
      year--;
    }

    return new Date(year, month);
  };

  Calendar.prototype.getDaysInMonth = function (month, year) {
    return new Date(year, month + 1, 0).getDate();
  };

  return Calendar;
}]);

'use strict';

angular.module('spbtvcalendarApp')
  .directive('calDate', ["$compile", function ($compile) {
    return {
      templateUrl: 'partials/directives/date.directive.html',
      restrict: 'A',
      link: function (scope, elem) {
        scope.dateElem = elem;
      },
      controller: ["$scope", function ($scope) {
        $scope.toggleEventWindow = function () {
          $compile($('<events-window></events-window>'))($scope);
        }
      }]
    };
  }]);

'use strict';

angular.module('spbtvcalendarApp')
  .factory('EventService', ["$localStorage", "dateFilter", function ($localStorage, dateFilter) {

    function obtainNewEventId() {
      if ($localStorage.lastEventId == undefined) {
        $localStorage.lastEventId = 0;
      }

      return ++$localStorage.lastEventId;
    }

    function getDateKey(date) {
      if (date instanceof Date) {
        return dateFilter(date, 'dd/MM/yyyy');
      }

      return date;
    }

    var eventService = {};

    eventService.getEvents = function (date) {
      var dateKey = getDateKey(date);

      return angular.fromJson($localStorage[dateKey]) || [];
    };

    eventService.saveEvents = function(events, date) {
      var dateKey = getDateKey(date);

      $localStorage[dateKey] = angular.toJson(events);
    };

    eventService.addEvent = function (event, date) {
      var dateKey = getDateKey(date);

      event.id = obtainNewEventId();
      this.saveEvent(event, dateKey);

      return event;
    };

    eventService.saveEvent = function (event, date) {
      var dateKey = getDateKey(date);

      var dateEvents = this.getEvents(dateKey);
      if (!dateEvents) {
        dateEvents = [];
      }

      // replace event if exists
      _.remove(dateEvents, {'id': event.id});
      dateEvents.push(event);

      this.saveEvents(dateEvents, dateKey);
    };

    eventService.removeEvent = function (eventId, date) {
      var dateKey = getDateKey(date);

      var events = this.getEvents(dateKey);
      if (!events) {
        return false;
      }

      var removed = _.remove(events, {'id': eventId}).length > 0;
      if (removed) {
        if(events.length > 0) {
          this.saveEvents(events, dateKey);
        } else {
          delete $localStorage[dateKey];
        }
      }

      return removed;
    };

    return eventService;
  }]);

'use strict';

angular.module('spbtvcalendarApp')
  .directive('eventsWindow', function () {
    return {
      templateUrl: 'partials/directives/events-window.directive.html',
      restrict: 'E',
      replace: true,
      link: function(scope, elem) {
        var $windowElem = $(elem),
            $dateElem = $(scope.dateElem);

        // close event window if exists
        var openedEventWindow = $('#events-window');

        if(openedEventWindow.length) {
          // event window was clicked again, just hide it
          if($dateElem.find(openedEventWindow).length) {
            openedEventWindow.remove();
            return;
          }

          openedEventWindow.remove();
        }

        $dateElem.append($windowElem);

        // if window doesn't fit in table, let's change floating to left
        if (!SpbTVCalendar.helpers.HorizontallyBound($windowElem.closest('table'), $windowElem)) {
          $windowElem.addClass('float-left');
        }

        // overflow scrollbar still persists after changing abs position
        // so let's reattach window element to reset scrollbar
        $windowElem.detach().appendTo($dateElem);

        $windowElem.find('textarea').focus();
      },
      controller: ["$scope", function($scope) {
        $scope.newEvent = {};

        $scope.remove = function (event) {
          $scope.removeEvent(event, $scope.date);
          _.remove($scope.date.events, event);
        };

        $scope.add = function () {
          $scope.newEvent = $scope.addEvent($scope.newEvent, $scope.date);
          $scope.date.events.push(angular.copy($scope.newEvent));
          $scope.newEvent = {};
        };

        $scope.submitForm = function() {
          if($scope.eventForm.newEvent.$valid) {
            $scope.add();
            $scope.eventForm.$setPristine();
            $scope.$apply();
          }
        }
      }]
    };
  });

'use strict';

angular.module('spbtvcalendarApp')
  .directive('ctrlEnter', function () {
    return {
      restrict: 'A',
      link: function postLink(scope, element, attrs) {
        var keysPressed = [];
        element.bind('keydown keyup', function(e){
          keysPressed[e.keyCode] = e.type == 'keydown';
          if(keysPressed[17] && keysPressed[13]) { // ctrl + enter
            scope.$eval(attrs.ctrlEnter);
          }
        });
      }
    };
  });

'use strict';

/**
 * @ngdoc directive
 * @name spbtvcalendarApp.directive:eventsList
 * @description
 * # eventsList
 */
angular.module('spbtvcalendarApp')
  .directive('eventsList', function () {
    return {
      templateUrl: 'partials/directives/events-list.directive.html',
      restrict: 'E',
      replace: true,
      scope: true,
      link: function(scope, element, attrs) {
        scope.events = scope.$eval(attrs.events);
        scope.fullList = scope.$eval(attrs.fullList);
        scope.remove = scope.$eval(attrs.remove);
        scope.limit = scope.$eval(attrs.limit);
      },
      controller: ["$scope", function($scope) {
        var evTitleLength = 11;

        $scope.getTitle = function (text) {
          text = text || "";
          return text.length > evTitleLength ? text.slice(0, evTitleLength) + '...' : text
        };
      }]
    };
  });
